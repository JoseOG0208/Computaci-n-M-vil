package com.example.sucesiontriangular.ui

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ListItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun ListScreen(number: String?) {
    val n = number?.toIntOrNull() ?: 0
    val sequence = triangularNumbers(n)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        contentPadding = PaddingValues(bottom = 16.dp)
    ) {
        itemsIndexed(sequence) { index, value ->
            ListItem(
                headlineContent = { Text(text = "$value") },
            )
            HorizontalDivider()
        }
    }
}

private fun triangularNumbers(n: Int): List<Int> {
    //serie: 0,1,3,6,10,... hasta n
    //Xn = n(n+1)/2
    return (0..n).map { i -> i * (i + 1) / 2 }
}
