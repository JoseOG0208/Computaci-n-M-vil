package com.example.sucesiontriangular.ui

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.sucesiontriangular.R
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType

@Composable
fun MainScreen(navController: NavController) {
    val context = LocalContext.current
    var input by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(35.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "Sucesión Triangular", fontSize = 25.sp)

        Spacer(modifier = Modifier.size(10.dp))

        Image(
            painter = painterResource(id = R.drawable.triangular),
            contentDescription = "Imagen triangular",
            modifier = Modifier
                .size(220.dp)
                .clip(CircleShape)
        )

        Spacer(modifier = Modifier.size(10.dp))

        OutlinedTextField(
            value = input,
            onValueChange = { new -> input = new.filter { it.isDigit() } },
            label = { Text("Ingrese un número") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
        )

        Spacer(modifier = Modifier.size(10.dp))

        Button(
            onClick = {
                val n = input.toIntOrNull()
                if (n == null || n !in 0..50) {
                    Toast.makeText(
                        context,
                        "El número está fuera del rango",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    navController.navigate("list_screen?number=$n")
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Calcular")
        }
    }
}
