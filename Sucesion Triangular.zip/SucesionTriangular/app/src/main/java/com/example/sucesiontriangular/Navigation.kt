package com.example.sucesiontriangular

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.sucesiontriangular.ui.ListScreen
import com.example.sucesiontriangular.ui.MainScreen

@Composable
fun NavigationStack() {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = "main_screen"
    ) {
        composable(route = "main_screen") {
            MainScreen(navController = navController)
        }

        composable(
            route = "list_screen?number={number}",
            arguments = listOf(
                navArgument("number") {
                    type = NavType.StringType
                    nullable = true
                }
            )
        ) { backStackEntry ->
            val number = backStackEntry.arguments?.getString("number")
            ListScreen(number = number)
        }
    }
}
