package com.example.taller1_compumovil.data.repository

import com.example.taller1_compumovil.data.model.UsersResponse
import com.example.taller1_compumovil.data.remote.ApiClient
import io.ktor.client.call.body
import io.ktor.client.request.get

//http para obtener los usuarios (ktor)
private const val API_USERS_URL = "https://dummyjson.com/users?limit=100"

//descarga los usuarios y devuelve la lista
class UsersRepository {
    suspend fun fetchUsers() =
        ApiClient.http.get(API_USERS_URL).body<UsersResponse>().users
}
