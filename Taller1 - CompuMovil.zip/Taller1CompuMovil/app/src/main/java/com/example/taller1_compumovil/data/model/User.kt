package com.example.taller1_compumovil.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class UsersResponse(val users: List<User>)

@Serializable
data class User(
    val id: Int,
    @SerialName("firstName") val firstName: String,
    @SerialName("lastName") val lastName: String,
    val image: String,
    val phone: String,
    val email: String? = null,
    val age: Int? = null,
    val gender: String? = null,
    val birthDate: String? = null,
    val bloodGroup: String? = null,
    val university: String? = null,
    val address: Address? = null,
    val company: Company? = null,
)

@Serializable
data class Address(val city: String? = null, val address: String? = null)

@Serializable
data class Company(val name: String? = null, val title: String? = null)
