package com.example.taller1_compumovil.data.remote

import io.ktor.client.HttpClient
import io.ktor.client.engine.android.Android
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.serialization.kotlinx.json.json
import kotlinx.serialization.json.Json

//cliente Ktor y configuracion de JSON para toda la app
object ApiClient {
    val json = Json { ignoreUnknownKeys = true; isLenient = true }
    val http = HttpClient(Android) {
        install(ContentNegotiation) { json(json) }
    }
}
