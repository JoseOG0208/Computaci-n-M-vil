package com.example.taller1_compumovil.navigation

import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.taller1_compumovil.UsersViewModel
import com.example.taller1_compumovil.ui.detail.UserDetailScreen
import com.example.taller1_compumovil.ui.list.UsersScreen

object Routes {
    const val LIST = "list"
    const val DETAIL = "detail/{userId}"
}

@Composable
fun AppNavGraph() {
    val nav = rememberNavController()

    //ViewModel único para toda la app
    val sharedVm: UsersViewModel = viewModel()

    NavHost(navController = nav, startDestination = Routes.LIST) {
        composable(Routes.LIST) {
            UsersScreen(onUserClick = { id -> nav.navigate("detail/$id") }, vm = sharedVm)
        }
        composable(
            route = Routes.DETAIL,
            arguments = listOf(navArgument("userId") { type = NavType.IntType })
        ) { backStackEntry ->
            val id = backStackEntry.arguments?.getInt("userId") ?: -1
            UserDetailScreen(userId = id, onBack = { nav.popBackStack() }, vm = sharedVm)
        }
    }
}
