package com.example.taller1_compumovil.ui.list

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.example.taller1_compumovil.UsersState
import com.example.taller1_compumovil.UsersViewModel
import com.example.taller1_compumovil.data.model.User

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
//lista de los usuarios
@Composable
fun UsersScreen(onUserClick: (Int) -> Unit, vm: UsersViewModel = viewModel()) {
    val state: UsersState = vm.state

    Scaffold(topBar = { TopAppBar(title = { Text("Usuarios") }) }) { padding ->
        when {
            //estado de carga
            state.loading -> Box(
                Modifier.fillMaxSize().padding(padding),
                contentAlignment = Alignment.Center
            ) { CircularProgressIndicator() }

            //error
            state.error != null -> Box(
                Modifier.fillMaxSize().padding(padding),
                contentAlignment = Alignment.Center
            ) { Text("Error: ${state.error}") }

            //contenido
            else -> {
                Box(Modifier.fillMaxSize().padding(padding)) {
                    //lista de usuarios
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(top = 56.dp) // alto aproximado del header
                    ) {
                        items(state.users, key = { it.id }) { user ->
                            UserListItem(user = user, onClick = { onUserClick(user.id) })
                            Divider()
                        }
                    }

                    Surface(
                        tonalElevation = 3.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.TopCenter)
                    ) {
                        Row(
                            Modifier.fillMaxWidth().padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Total de usuarios: ", style = MaterialTheme.typography.titleMedium)
                            Text(
                                state.users.size.toString(),
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

//item de la lista: imagen, nombre y empresa
@Composable
private fun UserListItem(user: User, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(
            model = user.image,
            contentDescription = "Avatar de ${user.firstName}",
            modifier = Modifier.size(56.dp)
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            //nombre y apellido
            Text(
                "${user.firstName} ${user.lastName}",
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            //empresa
            Text(
                user.company?.name ?: "—",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
        }
    }
}
