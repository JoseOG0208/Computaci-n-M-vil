package com.example.taller1_compumovil.ui.detail

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.example.taller1_compumovil.UsersViewModel
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack

@OptIn(ExperimentalMaterial3Api::class)
//Pantalla de detalle: muestra datos del usuario y permite marcar el telefono
@Composable
fun UserDetailScreen(userId: Int, onBack: () -> Unit, vm: UsersViewModel = viewModel()) {
    val user = vm.getById(userId)          //toma el usuario ya cargado en memoria
    val ctx = LocalContext.current          //contexto para lanzar el intent de llamadas

    Scaffold(topBar = {
        TopAppBar(
            //titulo con nombre completo o texto por defecto
            title = { Text(user?.let { "${it.firstName} ${it.lastName}" } ?: "Detalle") },
            //flecha atrás
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(imageVector = Icons.Filled.ArrowBack, contentDescription = "Atrás")
                }
            }
        )
    }) { padding ->
        if (user == null) {
            //caso borde: no se encontro el id
            Box(
                Modifier.fillMaxSize().padding(padding),
                contentAlignment = Alignment.Center
            ) { Text("Usuario no encontrado") }
        } else {
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                //encabezado: avatar + nombre + empresa
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AsyncImage(
                        model = user.image,
                        contentDescription = null,
                        modifier = Modifier.size(96.dp)
                    )
                    Spacer(Modifier.width(16.dp))
                    Column {
                        Text(
                            "${user.firstName} ${user.lastName}",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            user.company?.name ?: "—",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                //telefono (tap abre la app de llamadas con ACTION_DIAL)
                Row(Modifier.clickable {
                    val intent = Intent(Intent.ACTION_DIAL).apply {
                        data = Uri.parse("tel:${user.phone}")
                    }
                    ctx.startActivity(intent)
                }) {
                    Text("Teléfono: ", fontWeight = FontWeight.SemiBold)
                    Text(user.phone)
                }

                InfoRow("Email", user.email)
                InfoRow("Edad", user.age?.toString())
                InfoRow("Género", user.gender)
                InfoRow("Ciudad", user.address?.city)
                InfoRow("Cargo", user.company?.title)
                InfoRow("Universidad", user.university)
            }
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String?) {
    Row {
        Text("$label: ", fontWeight = FontWeight.SemiBold)
        Text(value ?: "—")
    }
}
