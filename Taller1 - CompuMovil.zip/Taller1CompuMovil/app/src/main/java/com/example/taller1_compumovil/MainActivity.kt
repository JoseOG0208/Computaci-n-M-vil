package com.example.taller1_compumovil

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.taller1_compumovil.navigation.AppNavGraph
import com.example.taller1_compumovil.ui.theme.AppTheme

//Activty principal de la app: arranca el compose y la navegacion
class MainActivity : ComponentActivity() {
    //se crea la activity y se monta la UI de compose
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //inicia los composables
        setContent {
            //tema claro/oscuro
            AppTheme {
                //grafo de navegacion
                AppNavGraph()
            }
        }
    }
}
