package com.example.taller1_compumovil

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.taller1_compumovil.data.model.User
import com.example.taller1_compumovil.data.repository.UsersRepository
import kotlinx.coroutines.launch

//ViewModel: carga la lista de usuarios desde el repositorio (Ktor)
class UsersViewModel(
    private val repo: UsersRepository = UsersRepository()
) : ViewModel() {

    var state by mutableStateOf(UsersState())
        private set

    //dispara la unica carga al crear el ViewModel
    init { fetchUsersOnce() }

    //carga los usuarios con Ktor una sola vez
    private fun fetchUsersOnce() {
        if (state.users.isNotEmpty() || state.loading) return
        //marca la UI en estado de carga
        state = state.copy(loading = true)
        viewModelScope.launch {
            runCatching { repo.fetchUsers() }
                .onSuccess { list ->
                    //actualiza los datos
                    state = state.copy(users = list, loading = false, error = null)
                }
                .onFailure { e ->
                    //reporta el error
                    state = state.copy(error = e.message ?: "Error desconocido", loading = false)
                }
        }
    }

    //busca un usuario por id en memoria
    fun getById(id: Int): User? = state.users.firstOrNull { it.id == id }
}

//estado de UI: datos, carga y error
data class UsersState(
    val users: List<User> = emptyList(),
    val loading: Boolean = false,
    val error: String? = null,
)
